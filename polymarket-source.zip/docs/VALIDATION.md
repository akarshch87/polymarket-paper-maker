# Validation: October 16, 2026

Local verification passed: **16 tests**, Ruff lint, Ruff format check, and strict mypy source checks. Tests run offline and use synthetic fixtures; they do not verify historical scale, production quality, realized financial results, or a live deployment.

```powershell
python -m pip install -e ".[dev]"
pytest
ruff check .
ruff format --check .
mypy src
```

Both baseline and inventory-aware replay commands ran on the checked-in five-event synthetic session, with an explicit 10-bps assumed fee. Each generated metrics and a Markdown report. Those outputs illustrate execution and cannot support a live performance or expected return claim. Current SDK model inspection found version 0.10.0; the public subscription now uses `asset_ids`. No fresh live-data stream was collected in this review.

GitHub Actions configuration is included, with read-only repository permissions. Remote CI success requires a verified Actions run. Docker was not run in this review.

## Local recheck: November 10, 2026

The isolated working copy passed 17 offline tests, Ruff lint and format checks, and strict mypy source checks. Both paper and baseline replay commands ran on synthetic data. This check did not test a live feed, PostgreSQL integration, Docker, or remote CI. Replay now rejects invalid capital, fees, and strategy inputs.

## Local recheck: November 18, 2026

Twenty offline tests pass, including checks for reproducible generated sessions,
shared input between strategies, and fills at the wrong price. Ruff and mypy
checks pass locally. A comparison with seed 20261118 generated 44 fictional
sessions containing 11,000 book events and 11,000 trade events. The inventory
strategy exceeded the midpoint baseline in 1 session. Its mean return difference
was approximately negative 0.216 percentage points, using 10,000 starting cash
and zero assumed fees for each replay. These results apply to the generated
random walk and execution assumptions only. They do not establish performance
on public market data or in live trading.

```powershell
polymm compare --output artifacts/study --seed 20261118 --sessions 44 --steps 250
```

## Replay risk controls and scenario recheck

The earlier 44 session result used the prior replay assumptions and is not comparable to the revised implementation. In the revised model, each condition below contains 16 sessions of 200 generated books and 200 generated trades per session. Seeds 71201 and 81201 represent separate input groups. The two fee settings reuse the same inputs within a group. Starting cash is 10,000 and the comparison is marked paper return.

| Scenario | Seed | Assumed fee | Midpoint mean return | Inventory mean return | Inventory wins |
| --- | ---: | ---: | ---: | ---: | ---: |
| Balanced | 71201 | 0 bps | 0.1432% | 0.0742% | 1 of 16 |
| Balanced | 71201 | 25 bps | 0.1372% | 0.0714% | 1 of 16 |
| Adverse | 71201 | 25 bps | 0.0892% | 0.0630% | 3 of 16 |
| Balanced | 81201 | 25 bps | 0.1502% | 0.0613% | 0 of 16 |
| Adverse | 81201 | 25 bps | 0.1074% | 0.0518% | 2 of 16 |

The inventory strategy had a lower average return than the midpoint strategy in each tested condition. These are synthetic results under specified assumptions, not a forecast or actual profit. The study models adverse selection only through a simple relationship between trade direction and the next midpoint. It does not calibrate that relationship from market data or model real exchange fill priority.
