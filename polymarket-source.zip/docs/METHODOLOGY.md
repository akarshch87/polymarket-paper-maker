# Methodology

## Fair value and quotes

The midpoint is `(best_bid + best_ask) / 2`. The microprice is `(best_ask * bid_depth + best_bid * ask_depth) / total_depth`. The weighted mode nudges midpoint by a bounded fraction of spread times imbalance. Quotes add a base half-spread and observed volatility, then subtract an inventory skew from both prices. For a long inventory, both quotes move down: the bid becomes less attractive and the ask becomes more competitive.

## Queue-aware simulation

At submission, visible size at the quoted level becomes estimated queue-ahead. A conservative model assumes all visible size is ahead; an optimistic model assumes only a quarter is ahead. A later trade must be at the same price and exceed queue-ahead before a fill is possible. A trade at another price does not tell us how much volume traded at the quote. Remaining size can be partially filled. This is deliberately not an exchange fill guarantee.

## Markouts and comparisons

For each fill, record future midpoint at 5s, 30s, 60s, and 5m. Positive side-adjusted markout means the fill price was favorable. Compare an inventory-aware strategy with the static midpoint baseline on the same recorded event stream, with parameters fixed before inspecting results. Never select a denominator or a time window after looking at performance.


## Implemented replay assumptions

Only opposite side aggressor prints can fill a resting order. Each print has one volume budget shared across eligible orders in price and time order. Queue ahead is consumed before fills; reported fill rate counts unique filled orders rather than fill fragments. On book updates, unchanged eligible orders retain their estimated queue position; changed or disallowed orders are canceled. Both strategies consume the same normalized session; baseline uses midpoint and zero inventory skew. Inventory aware uses microprice with a fixed skew of 0.0005 per token, reaching five cents at the 100 token limit. This is an assumption chosen for interpretability, not a calibrated exchange parameter.

Markouts use the first observed midpoint at or after each fill plus 5, 30, 60, or 300 seconds. Sparse observations can be later than the requested horizon, so report observation density before comparing strategies. Unobserved horizons remain null. Drawdown is the maximum observed marked equity peak to trough fraction across session events. A user specified fee in basis points of notional is subtracted from cash. Realized P&L is shown before fees; paper return includes deducted fees. Replay starts with cash and no tokens, restricts sales to owned inventory, funds bids including modeled fees, and limits holdings to 100 tokens. These controls do not prove real exchange collateral feasibility.

Collected trades are marked with unspecified side semantics. Replay rejects them until the direction has been verified as aggressor side and the normalized field is set to `aggressor`. Generated data explicitly assumes its side is aggressor direction. For input without a tick field the simulator assumes 0.01; real market metadata should be verified before replay. A recorded tick change is applied and stale resting prices are replaced. Normalized price change batches are currently processed one event at a time, which can quote between members of a single exchange message. The model therefore cannot establish exact event ordering or fill priority from public data.

The balanced generator uses an uncorrelated random walk. The adverse generator moves the next midpoint in the previous aggressor direction with 75 percent probability. Repeated fee scenarios reuse the same input for the same seed. Both are fictional models, with no inference about real market probabilities.
