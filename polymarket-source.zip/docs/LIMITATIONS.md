# Limitations

- Public data cannot identify the hypothetical order's real exchange queue position.
- The current demo run uses a tiny synthetic fixture and is not evidence of live performance.
- Latency, participant cancellations, fees, resolution mechanics, and cross-market hedging are simplified.
- Replay supports a normalized, ordered, single-token session. It is event-dependent, but it is not a full exchange simulator. Multi-token portfolio netting, exchange collateral constraints, latency, settlement, and complete feed recovery are not implemented.
- PostgreSQL schema is included, but database wiring is intentionally not required for the offline demo.
- Polymarket API and SDK schemas can change; recheck the official documentation before upgrades.

- The portfolio object supports hypothetical shorts for accounting tests, while replay only sells tokens already held. Replay enforces a simplified cash and inventory limit, not the platform's complete collateral or minimum order rules.
- Unchanged orders retain estimated queue position. Fees are a user specified notional basis assumption. Passive fills execute at the quoted price with no extra slippage assumption. Queue uncertainty and latency remain substantial model risk.
- Separate resting orders use conservative queue estimates and share a print-volume budget in price/time order. This prevents volume double counting but cannot recover true exchange queue priority.
- The current live data adapters were inspected against installed SDK models; this review did not run a fresh live feed recording or claim end-to-end live operation.
- Market discovery filters and sorts within a bounded first set of candidates, not the full global market catalogue. Public price change batches are replayed one member at a time rather than atomically.
