"""Seeded fictional sessions for exercising the replay engine offline."""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from random import Random
from typing import Any

from polymarket_mm.replay import replay_session


def generate_session(seed: int, steps: int) -> list[dict[str, Any]]:
    if not 1 <= steps <= 100_000:
        raise ValueError("steps must be between 1 and 100000")
    rng = Random(seed)
    start = datetime(2026, 10, 16, 12, tzinfo=timezone.utc)
    midpoint = 50
    events: list[dict[str, Any]] = []
    for step in range(steps):
        midpoint = max(10, min(90, midpoint + rng.choice((-1, 0, 0, 1))))
        time = start + timedelta(seconds=step * 2)

        def price(cents: int) -> str:
            return f"0.{cents:02d}"

        events.append(
            {
                "type": "book",
                "token_id": "synthetic-yes",
                "timestamp": time.isoformat(),
                "bids": [[price(midpoint - 2), str(rng.randint(1, 20))]],
                "asks": [[price(midpoint + 2), str(rng.randint(1, 20))]],
            }
        )
        sell = rng.choice((True, False))
        offset = rng.choice((2, 3, 4))
        events.append(
            {
                "type": "trade",
                "token_id": "synthetic-yes",
                "timestamp": (time + timedelta(seconds=1)).isoformat(),
                "side": "SELL" if sell else "BUY",
                "price": price(midpoint - offset if sell else midpoint + offset),
                "size": str(rng.randint(1, 30)),
            }
        )
    return events


def compare_sessions(output: Path, seed: int, sessions: int, steps: int) -> dict[str, Any]:
    if not 1 <= sessions <= 1_000:
        raise ValueError("sessions must be between 1 and 1000")
    # Validate before creating the output directory. Existing results are never replaced.
    generate_session(seed, steps)
    output.mkdir(parents=True, exist_ok=False)
    rows = []
    for index in range(sessions):
        session = output / f"session-{index:04d}.jsonl"
        events = generate_session(seed + index, steps)
        session.write_text(
            "".join(json.dumps(event, sort_keys=True) + "\n" for event in events), encoding="utf-8"
        )
        baseline = replay_session(
            session, "baseline", Decimal("10000"), output / f"baseline-{index:04d}"
        )
        inventory = replay_session(
            session, "inventory-aware", Decimal("10000"), output / f"inventory-{index:04d}"
        )
        rows.append(
            {
                "seed": seed + index,
                "baseline_return": baseline["paper_return"],
                "inventory_return": inventory["paper_return"],
                "baseline_fills": baseline["simulated_fills"],
                "inventory_fills": inventory["simulated_fills"],
            }
        )
    differences = [
        Decimal(str(row["inventory_return"])) - Decimal(str(row["baseline_return"])) for row in rows
    ]
    summary = {
        "data_source": "synthetic, not historical",
        "seed": seed,
        "sessions": sessions,
        "book_events": sessions * steps,
        "trade_events": sessions * steps,
        "starting_capital": "10000",
        "assumed_fee_bps": "0",
        "comparison": "inventory-aware minus baseline paper return on identical sessions",
        "mean_return_difference": str(sum(differences, Decimal(0)) / sessions),
        "inventory_above_baseline": sum(value > 0 for value in differences),
        "results": rows,
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return summary
