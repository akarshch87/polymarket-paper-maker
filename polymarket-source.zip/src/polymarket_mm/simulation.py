from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from uuid import uuid4

from polymarket_mm.models import Fill, PaperOrder, Quote, Side


class QueueModel:
    """Conservative observable approximation; exact exchange priority is unknowable."""

    def __init__(self, participation: Decimal) -> None:
        if not Decimal("0") < participation <= Decimal("1"):
            raise ValueError("participation must be in (0, 1]")
        self.participation = participation

    def queue_ahead(self, visible_size: Decimal) -> Decimal:
        return visible_size * self.participation


OPTIMISTIC_QUEUE = QueueModel(Decimal("0.25"))
CONSERVATIVE_QUEUE = QueueModel(Decimal("1.0"))


class PaperExchange:
    """A fill simulator. It can never place a network order or authenticate a wallet."""

    def __init__(self, queue_model: QueueModel = CONSERVATIVE_QUEUE) -> None:
        self.queue_model = queue_model
        self.orders: dict[str, PaperOrder] = {}
        self._open_orders: dict[str, PaperOrder] = {}
        self.fills: list[Fill] = []

    def submit(
        self,
        quote: Quote,
        visible_bid: Decimal,
        visible_ask: Decimal,
        buy_size: Decimal | None = None,
        sell_size: Decimal | None = None,
        timestamp: datetime | None = None,
    ) -> list[PaperOrder]:
        now = timestamp or datetime.now(timezone.utc)
        orders = [
            PaperOrder(
                str(uuid4()),
                quote.token_id,
                "BUY",
                quote.bid,
                quote.size if buy_size is None else buy_size,
                quote.size if buy_size is None else buy_size,
                now,
                self.queue_model.queue_ahead(visible_bid),
            ),
            PaperOrder(
                str(uuid4()),
                quote.token_id,
                "SELL",
                quote.ask,
                quote.size if sell_size is None else sell_size,
                quote.size if sell_size is None else sell_size,
                now,
                self.queue_model.queue_ahead(visible_ask),
            ),
        ]
        orders = [order for order in orders if order.size > 0]
        for order in orders:
            self.orders[order.order_id] = order
            self._open_orders[order.order_id] = order
        return orders

    def reconcile(
        self,
        quote: Quote,
        visible_bid: Decimal,
        visible_ask: Decimal,
        buy_size: Decimal,
        sell_size: Decimal,
        timestamp: datetime,
    ) -> None:
        """Retain unchanged resting orders and their queue position across book updates."""
        wanted = {"BUY": (quote.bid, buy_size), "SELL": (quote.ask, sell_size)}
        create = {"BUY": buy_size, "SELL": sell_size}
        for order in list(self._open_orders.values()):
            if order.status != "OPEN" or order.token_id != quote.token_id:
                continue
            price, limit = wanted[order.side]
            if order.price == price and 0 < order.remaining <= limit:
                create[order.side] = Decimal("0")
            else:
                self.cancel(order.order_id)
        self.submit(quote, visible_bid, visible_ask, create["BUY"], create["SELL"], timestamp)

    def consume_trade(
        self,
        token_id: str,
        side: Side,
        price: Decimal,
        size: Decimal,
        timestamp: datetime | None = None,
    ) -> list[Fill]:
        """Consume prints at our price; queue ahead is consumed first."""
        if side not in {"BUY", "SELL"} or size < 0 or not 0 < price < 1:
            raise ValueError("trade requires a valid aggressor side, price and nonnegative size")
        output: list[Fill] = []
        remaining_volume = size
        candidates = sorted(
            self._open_orders.values(),
            key=lambda order: (
                order.price if side == "BUY" else -order.price,
                order.submitted_at,
            ),
        )
        for order in candidates:
            if remaining_volume <= 0:
                break
            if order.status != "OPEN" or order.token_id != token_id or order.side == side:
                continue
            # A print at another price does not tell us how much traded at our
            # price, so it cannot safely be used as volume for our order.
            if price != order.price:
                continue
            consumed_queue = min(remaining_volume, order.queue_ahead)
            order.queue_ahead -= consumed_queue
            remaining_volume -= consumed_queue
            filled = min(order.remaining, remaining_volume)
            if filled <= 0:
                continue
            order.remaining -= filled
            remaining_volume -= filled
            if order.remaining == 0:
                order.status = "FILLED"
                self._open_orders.pop(order.order_id, None)
            fill = Fill(
                order.order_id,
                order.token_id,
                order.side,
                order.price,
                filled,
                timestamp or datetime.now(timezone.utc),
            )
            self.fills.append(fill)
            output.append(fill)
        return output

    def cancel(self, order_id: str) -> None:
        order = self.orders[order_id]
        if order.status == "OPEN":
            order.status = "CANCELLED"
            self._open_orders.pop(order_id, None)
