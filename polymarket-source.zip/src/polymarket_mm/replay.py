"""Event-time replay of an explicit, normalized, single-token research session."""

from __future__ import annotations

import json
from bisect import bisect_left
from datetime import datetime, timedelta
from decimal import ROUND_DOWN, Decimal
from pathlib import Path
from typing import Any, cast

from polymarket_mm.book.order_book import OrderBook
from polymarket_mm.evaluation import side_adjusted_markout
from polymarket_mm.features import FeatureEngine
from polymarket_mm.models import Level, Side
from polymarket_mm.persistence import write_run_artifacts
from polymarket_mm.portfolio import Portfolio
from polymarket_mm.simulation import PaperExchange
from polymarket_mm.strategy import make_quote


def replay_session(
    session: Path,
    strategy: str,
    starting_capital: Decimal,
    output: Path,
    fee_bps: Decimal = Decimal("0"),
) -> dict[str, object]:
    if not starting_capital.is_finite() or starting_capital <= 0:
        raise ValueError("starting_capital must be finite and positive")
    if not fee_bps.is_finite() or not 0 <= fee_bps <= 10000:
        raise ValueError("fee_bps must be finite and between zero and 10000")
    if strategy not in {"baseline", "inventory-aware"}:
        raise ValueError("unknown strategy")
    events: list[dict[str, Any]] = [
        json.loads(line)
        for line in session.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if not events:
        raise ValueError("session is empty")
    token = str(events[0]["token_id"])
    book = OrderBook(token)
    exchange, portfolio, features = PaperExchange(), Portfolio(starting_capital), FeatureEngine()
    midpoints: list[tuple[datetime, Decimal]] = []
    last_time: datetime | None = None
    peak, drawdown, fees = starting_capital, Decimal("0"), Decimal("0")
    updates = 0
    for event in events:
        if str(event["token_id"]) != token:
            raise ValueError("replay supports one token per session; split multi-token recordings")
        timestamp = datetime.fromisoformat(str(event["timestamp"]).replace("Z", "+00:00"))
        if timestamp.tzinfo is None or (last_time is not None and timestamp < last_time):
            raise ValueError("events require timezone-aware, nondecreasing timestamps")
        last_time = timestamp
        kind = event.get("type")
        if kind == "book":
            tick = Decimal(str(event.get("tick_size", book.state.tick_size)))
            if not tick.is_finite() or not 0 < tick < Decimal("0.5"):
                raise ValueError("invalid tick size")
            book.apply_snapshot(
                [Level(Decimal(str(p)), Decimal(str(q))) for p, q in event["bids"]],
                [Level(Decimal(str(p)), Decimal(str(q))) for p, q in event["asks"]],
                timestamp,
                tick_size=tick,
            )
        elif kind == "change":
            book.apply_change(
                event["side"], Decimal(str(event["price"])), Decimal(str(event["size"])), timestamp
            )
        elif kind == "trade":
            if book.state.midpoint is None:
                raise ValueError("a complete book must precede trades")
            if event.get("side_semantics", "aggressor") != "aggressor":
                raise ValueError(
                    "trade side must be confirmed as aggressor direction before replay"
                )
            for fill in exchange.consume_trade(
                token,
                cast(Side, event["side"]),
                Decimal(str(event["price"])),
                Decimal(str(event["size"])),
                timestamp,
            ):
                portfolio.apply_fill(fill)
                fee = fill.price * fill.size * fee_bps / Decimal("10000")
                portfolio.cash -= fee
                fees += fee
        elif kind == "tick_size_change":
            tick = Decimal(str(event["tick_size"]))
            if not tick.is_finite() or not 0 < tick < Decimal("0.5"):
                raise ValueError("invalid tick size")
            book.state.tick_size = tick
        else:
            raise ValueError("unsupported event type; normalize SDK events before replay")
        midpoint = book.state.midpoint
        if midpoint is None:
            raise ValueError("replay requires nonempty bids and asks")
        midpoints.append((timestamp, midpoint))
        if kind in {"book", "change", "tick_size_change"}:
            updates += 1
            current = features.calculate(book)
            assert current is not None
            quote = make_quote(
                token,
                current,
                portfolio.inventory,
                book.state.tick_size,
                # Five cents of skew at the 100 share inventory limit.
                inventory_coefficient=Decimal("0.0005")
                if strategy == "inventory-aware"
                else Decimal("0"),
                fair_value_mode="microprice" if strategy == "inventory-aware" else "midpoint",
            )
            # A passive-only simulator must not pretend a marketable quote rests.
            buy_size = min(
                quote.size,
                max(Decimal("0"), Decimal("100") - portfolio.inventory),
                portfolio.cash / (quote.bid * (1 + fee_bps / Decimal("10000"))),
            ).quantize(Decimal("0.0001"), rounding=ROUND_DOWN)
            sell_size = min(quote.size, portfolio.inventory)
            if quote.bid >= book.state.best_ask:  # type: ignore[operator]
                buy_size = Decimal("0")
            if quote.ask <= book.state.best_bid:  # type: ignore[operator]
                sell_size = Decimal("0")
            exchange.reconcile(
                quote,
                book.state.bids.get(quote.bid, Decimal("0")),
                book.state.asks.get(quote.ask, Decimal("0")),
                buy_size,
                sell_size,
                timestamp,
            )
        value = portfolio.marked_value(midpoint)
        peak = max(peak, value)
        drawdown = max(drawdown, (peak - value) / peak)
    markouts: dict[str, str | None] = {}
    midpoint_times = [time for time, _ in midpoints]
    for horizon in (5, 30, 60, 300):
        values = []
        for fill in exchange.fills:
            index = bisect_left(midpoint_times, fill.timestamp + timedelta(seconds=horizon))
            future = midpoints[index][1] if index < len(midpoints) else None
            if future is not None:
                values.append(side_adjusted_markout(fill, future))
        markouts[f"mean_{horizon}s_markout"] = (
            str(sum(values, Decimal("0")) / len(values)) if values else None
        )
    filled_orders = len({fill.order_id for fill in exchange.fills})
    metrics: dict[str, object] = {
        "markets_monitored": 1,
        "replayed_events": len(events),
        "order_book_updates": updates,
        "simulated_orders": len(exchange.orders),
        "simulated_fills": len(exchange.fills),
        "filled_orders": filled_orders,
        "fill_rate": filled_orders / len(exchange.orders) if exchange.orders else 0.0,
        "realized_pnl_before_fees": str(portfolio.realized_pnl),
        "unrealized_pnl": str(portfolio.unrealized_pnl(midpoints[-1][1])),
        "paper_return": str(portfolio.return_on_starting_capital(midpoints[-1][1])),
        "max_drawdown_fraction": str(drawdown),
        "max_inventory": str(portfolio.max_inventory),
        "ending_inventory": str(portfolio.inventory),
        "ending_cash": str(portfolio.cash),
        "inventory_limit": "100",
        "fees": str(fees),
        "fee_bps_assumption": str(fee_bps),
        "strategy": strategy,
        "data_source": "normalized session replay; synthetic unless provenance independently verified",
        "session_file": session.name,
        **markouts,
    }
    write_run_artifacts(
        output,
        metrics,
        "# Paper session replay\n\n```json\n" + json.dumps(metrics, indent=2) + "\n```\n",
    )
    return metrics
