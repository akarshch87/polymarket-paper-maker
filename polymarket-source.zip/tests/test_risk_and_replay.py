import json
from datetime import datetime, timezone
from decimal import Decimal as D
from pathlib import Path

import pytest

from polymarket_mm.book.order_book import OrderBook
from polymarket_mm.data.normalize import normalize_event
from polymarket_mm.data.stream import collect_jsonl
from polymarket_mm.features import FeatureEngine
from polymarket_mm.models import Level, Quote
from polymarket_mm.replay import replay_session
from polymarket_mm.simulation import PaperExchange
from polymarket_mm.strategy import make_quote


def test_queue_position_survives_unchanged_updates() -> None:
    exchange = PaperExchange()
    quote = Quote("yes", D("0.48"), D("0.52"), D("10"), D("0.5"), "test")
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    exchange.reconcile(quote, D("10"), D("0"), D("10"), D("0"), now)
    assert not exchange.consume_trade("yes", "SELL", D("0.48"), D("6"), now)
    exchange.reconcile(quote, D("10"), D("0"), D("10"), D("0"), now)
    fills = exchange.consume_trade("yes", "SELL", D("0.48"), D("6"), now)
    assert [f.size for f in fills] == [D("2")]
    assert len(exchange.orders) == 1


def test_quotes_at_boundaries_use_distinct_ticks() -> None:
    for midpoint in (D("0.02"), D("0.98")):
        book = OrderBook("yes", D("0.01"))
        book.apply_snapshot(
            [Level(midpoint - D("0.01"), D("1"))], [Level(midpoint + D("0.01"), D("1"))]
        )
        feature = FeatureEngine().calculate(book)
        assert feature is not None
        for tick in (D("0.01"), D("0.03")):
            quote = make_quote("yes", feature, tick_size=tick)
            assert 0 < quote.bid < quote.ask < 1
            assert quote.bid % tick == quote.ask % tick == 0


def test_replay_never_sells_unowned_tokens_or_exceeds_cash(tmp_path: Path) -> None:
    events = [
        {
            "type": "book",
            "token_id": "yes",
            "timestamp": "2026-01-01T00:00:00Z",
            "bids": [["0.48", "0.1"]],
            "asks": [["0.52", "0.1"]],
        },
        {
            "type": "trade",
            "token_id": "yes",
            "timestamp": "2026-01-01T00:00:01Z",
            "side": "BUY",
            "price": "0.52",
            "size": "1000",
        },
        {
            "type": "trade",
            "token_id": "yes",
            "timestamp": "2026-01-01T00:00:02Z",
            "side": "SELL",
            "price": "0.48",
            "size": "1000",
        },
    ]
    path = tmp_path / "session.jsonl"
    path.write_text("\n".join(json.dumps(event) for event in events))
    result = replay_session(path, "baseline", D("1"), tmp_path / "out", D("25"))
    assert D(str(result["ending_cash"])) >= 0
    assert D("0") <= D(str(result["ending_inventory"])) <= D("100")
    assert result["simulated_fills"] == 1


def test_tick_change_is_preserved_and_applied(tmp_path: Path) -> None:
    event = {
        "type": "tick_size_change",
        "payload": {
            "asset_id": "yes",
            "timestamp": "2026-01-01T00:00:01Z",
            "new_tick_size": "0.001",
        },
    }
    normalized = normalize_event(event)
    assert normalized[0]["tick_size"] == "0.001"
    book = {
        "type": "book",
        "token_id": "yes",
        "timestamp": "2026-01-01T00:00:00Z",
        "bids": [["0.48", "2"]],
        "asks": [["0.52", "2"]],
    }
    path = tmp_path / "ticks.jsonl"
    path.write_text("\n".join(json.dumps(e) for e in [book, *normalized]))
    assert replay_session(path, "baseline", D("100"), tmp_path / "out")["order_book_updates"] == 2


def test_collector_does_not_replace_a_recording(tmp_path: Path) -> None:
    path = tmp_path / "capture.jsonl"
    path.write_text("preserve")
    with pytest.raises(FileExistsError):
        collect_jsonl(str(path), ["yes"], 1).send(None)
    assert path.read_text() == "preserve"


def test_unverified_collected_trade_side_is_not_used_for_fills(tmp_path: Path) -> None:
    trade = normalize_event(
        {
            "type": "last_trade_price",
            "payload": {
                "asset_id": "yes",
                "timestamp": "2026-01-01T00:00:01Z",
                "side": "SELL",
                "price": "0.48",
                "size": "10",
            },
        }
    )[0]
    assert trade["side_semantics"] == "unspecified"
    book = {
        "type": "book",
        "token_id": "yes",
        "timestamp": "2026-01-01T00:00:00Z",
        "bids": [["0.48", "1"]],
        "asks": [["0.52", "1"]],
    }
    path = tmp_path / "unknown.jsonl"
    path.write_text("\n".join(json.dumps(event) for event in (book, trade)))
    with pytest.raises(ValueError, match="aggressor"):
        replay_session(path, "baseline", D("100"), tmp_path / "out")
