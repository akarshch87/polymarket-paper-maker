import json
from pathlib import Path

import pytest

from polymarket_mm.synthetic import compare_sessions, generate_session


def test_generated_sessions_are_seeded_and_valid() -> None:
    events = generate_session(19, 100)
    assert events == generate_session(19, 100)
    assert events != generate_session(20, 100)
    assert len(events) == 200
    assert all(
        float(e["bids"][0][0]) < float(e["asks"][0][0]) for e in events if e["type"] == "book"
    )


def test_comparison_replays_identical_sessions_and_preserves_outputs(tmp_path: Path) -> None:
    output = tmp_path / "study"
    result = compare_sessions(output, 19, 2, 30)
    assert result["book_events"] == 60
    assert result["trade_events"] == 60
    assert json.loads((output / "summary.json").read_text()) == result
    for index in range(2):
        for strategy in ("baseline", "inventory"):
            metrics = json.loads((output / f"{strategy}-{index:04d}" / "metrics.json").read_text())
            assert metrics["order_book_updates"] == 30
            assert metrics["session_file"] == f"session-{index:04d}.jsonl"
    with pytest.raises(FileExistsError):
        compare_sessions(output, 19, 2, 30)
