# Methodology

## Fair value and quotes

The midpoint is `(best_bid + best_ask) / 2`. The microprice is `(best_ask * bid_depth + best_bid * ask_depth) / total_depth`. The weighted mode nudges midpoint by a bounded fraction of spread times imbalance. Quotes add a base half-spread and observed volatility, then subtract an inventory skew from both prices. For a long inventory, both quotes move down: the bid becomes less attractive and the ask becomes more competitive.

## Queue-aware simulation

At submission, visible size at the quoted level becomes estimated queue-ahead. A conservative model assumes all visible size is ahead; an optimistic model assumes only a quarter is ahead. A later trade must reach the price and exceed queue-ahead before a fill is possible. Remaining size can be partially filled. This is deliberately not an exchange fill guarantee.

## Markouts and comparisons

For each fill, record future midpoint at 5s, 30s, 60s, and 5m. Positive side-adjusted markout means the fill price was favorable. Compare an inventory-aware strategy with the static midpoint baseline on the same recorded event stream, with parameters fixed before inspecting results. Never select a denominator or a time window after looking at performance.


## Implemented replay assumptions

Only opposite-side aggressor prints can fill a resting order. Each print has one volume budget shared across eligible orders in price/time order. Queue-ahead is consumed before fills; reported fill rate counts unique filled orders rather than fill fragments. Book updates cancel previous open quotes and generate new passive quotes. Both baseline and inventory-aware strategies consume the supplied normalized session; baseline uses midpoint and zero inventory skew.

Markouts use the first observed midpoint at or after each fill plus 5, 30, 60, or 300 seconds. Sparse observations can be later than the requested horizon, so report observation density before comparing strategies. Unobserved horizons remain null. Drawdown is the maximum observed marked-equity peak-to-trough fraction across session events. A user-specified fee in basis points of notional is subtracted from cash. Realized P&L is shown before fees; paper return includes deducted fees. Hypothetical long/short cost basis reconciles to marked equity but does not prove live collateral feasibility.
