# Validation: October 16, 2026

Local verification passed: **16 tests**, Ruff lint, Ruff format check, and strict mypy source checks. Tests run offline and use synthetic fixtures; they do not verify historical scale, production quality, realized financial results, or a live deployment.

```powershell
python -m pip install -e ".[dev]"
pytest
ruff check .
ruff format --check .
mypy src
```

Both baseline and inventory-aware replay commands ran on the checked-in five-event synthetic session, with an explicit 10-bps assumed fee. Each generated metrics and a Markdown report. Those outputs illustrate execution and cannot support a live performance or expected return claim. Current SDK model inspection found version 0.10.0; the public subscription now uses `asset_ids`. No fresh live-data stream was collected in this review.

GitHub Actions configuration is included, with read-only repository permissions. Remote CI success requires a verified Actions run. Docker was not run in this review.

## Local recheck: November 10, 2026

The isolated working copy passed 17 offline tests, Ruff lint and format checks, and strict mypy source checks. Both paper and baseline replay commands ran on synthetic data. This check did not test a live feed, PostgreSQL integration, Docker, or remote CI. Replay now rejects invalid capital, fees, and strategy inputs.
