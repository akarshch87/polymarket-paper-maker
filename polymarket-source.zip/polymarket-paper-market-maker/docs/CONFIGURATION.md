# Configuration

Python 3.12+; install `python -m pip install -e ".[dev]"`. The tested SDK version is `polymarket-client` 0.10.0, constrained to `<0.11`. Offline `paper` and `replay` commands need no wallet, credentials, or network. `discover` and `collect` use only the public client. `--token-id` means a public asset identifier. `collect --duration` is bounded even if the stream produces no events, and creates the output directory.

Replay options: `--session PATH`, `--strategy baseline|inventory-aware`, `--starting-capital 10000`, `--fee-bps 0`, and `--output PATH`. Input JSONL uses `type`, `token_id`, and a timezone-aware `timestamp`. `book` has bids/asks as `[price,size]` pairs; `change` has `side`, `price`, and `size`; `trade` has an aggressor side, price, and size. Decimal values may be strings. Events must be nondecreasing and use one token. The checked-in synthetic fixture is the schema example.

The `.env.example` is illustrative; the CLI does not automatically load dotenv values. PostgreSQL persistence remains a schema/design artifact. The demonstrated execution engine is in-memory and cannot place network orders. Runtime exchange fees, slippage, risk limits, and collateral requirements must not be inferred from the sample configuration.

For the optional PostgreSQL container, set `POSTGRES_PASSWORD` in your environment to a strong value before running `docker compose up`. Compose requires the variable and supplies no password default. The schema initializes a new database volume; the application does not currently read from or write to PostgreSQL. Do not commit your password.
