# Git/GitHub guide

Git is the version history; GitHub is a remote collaboration and review service. A repository contains the project and its history. The working tree is the files on disk. `git status` shows changed files. Staging selects the next snapshot, and `git commit` records that snapshot with a message.

```powershell
git status
git diff
git add src tests
git commit -m "feat: add local order-book state"
git log --oneline --decorate --graph
git switch -c experiment
git push -u origin main
git pull --ff-only
git clone <url>
```

`main` is the stable default branch. Branches isolate work. A pull request asks for review and merges a branch into `main`; merge creates a combined history. `README.md` explains the project, `.gitignore` prevents generated/secrets from being tracked, Issues track work, and GitHub Actions runs the CI workflow on pushes and pull requests.

Never commit `.env`, private keys, wallet credentials, or database passwords. Use `.env.example` for names only and GitHub Actions secrets for CI credentials. If a secret is committed, removing the line is not enough: revoke/rotate it and rewrite history only with care.

The meaningful commits in this build are real snapshots made after each phase. Use `git status` before every commit, inspect `git diff --cached`, write a small imperative message, and push only after local tests pass. The local repository can exist without a GitHub remote; adding `origin` and pushing are separate actions.
