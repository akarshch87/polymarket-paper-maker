# Learning guide

1. A prediction market prices a possible outcome; a binary YES token is bounded between 0 and 1.
2. A central limit order book stores resting bids and asks at price levels.
3. Bid is the highest displayed buy price; ask is the lowest displayed sell price; spread is ask minus bid.
4. Midpoint is a simple reference, not necessarily fair value.
5. A market maker posts both sides and earns spread only if fills are not followed by unfavorable moves.
6. Depth is available size at levels; imbalance compares bid and ask depth.
7. Microprice uses depth to shift the midpoint toward the side with less available liquidity.
8. Volatility measures recent price movement; inventory risk is the risk of holding too much outcome exposure.
9. Adverse selection means informed or faster flow fills the quote just before price moves against it.
10. A markout asks whether price moved favorably after a fill.
11. Queue position is unknown in public data, so the simulator is conservative.
12. Partial fills reduce the false precision of a touch-based simulator.
13. Realized P&L is closed-trade result; unrealized P&L marks current inventory.
14. WebSockets stream changes; REST/SDK pagination discovers state and recovers from gaps.
15. Async Python lets one process manage long-lived I/O without blocking every market.
16. PostgreSQL gives durable relational state and JSONB for source payloads; Docker makes local setup repeatable.
17. Unit tests isolate pure calculations; integration tests exercise boundaries; replay tests use the same events for fair comparisons.

Start with `models.py`, then `book/order_book.py`, `features.py`, `strategy.py`, `simulation.py`, `portfolio.py`, `evaluation.py`, `data/market_discovery.py`, `data/stream.py`, and finally `cli/main.py`.
