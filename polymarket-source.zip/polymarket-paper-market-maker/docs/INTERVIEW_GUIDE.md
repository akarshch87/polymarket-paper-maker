# Interview guide

- **Why WebSockets instead of polling?** Polling is simpler for discovery; a stream reduces repeated reads for fast book changes. The adapter still needs reconnect and stale-data protection.
- **How is local state maintained?** A snapshot replaces levels; a price change updates or deletes one level; crossed books are rejected.
- **Why might midpoint be poor fair value?** It ignores depth, volatility, latency, and informed flow.
- **How does inventory affect quotes?** A long position shifts both quotes lower, discouraging more buys and encouraging sells.
- **What is adverse selection?** A fill is followed by a move against the maker; markouts measure it.
- **Why is exact queue position unknowable?** Public feeds do not reveal the hypothetical order's priority among all orders at a level.
- **How do you avoid look-ahead bias?** Quotes use only state available before the simulated fill; evaluation uses later timestamps.
- **Why can spread capture be positive while P&L is negative?** Inventory revaluation and adverse selection can exceed captured spread.
- **How would live execution differ?** Authentication, signing, rate limits, acknowledgements, cancellation races, fees, and real queue priority would be required. This repository intentionally has none of that.
- **Why PostgreSQL and Docker?** Relational constraints fit orders/fills/runs, JSONB preserves source payloads, and Docker makes the database reproducible.
- **What result surprised you?** Only answer from a recorded run; this repository does not invent a surprise.
