# Provenance and claims policy

This repository is an independent, AI-assisted prototype created at the owner's request in September 2026 and reviewed and improved on October 16, 2026. It is not recovered historical source code that proves earlier resume metrics. The owner must understand and be able to explain the implementation and distinguish personal engineering work from AI assistance.

The checked-in MIT license names Akarsh Choudhary. This review found no employer code or dataset in the tracked source. The license applies to the original example code and synthetic fixtures, not third-party libraries, platform content, or any separate historical implementation. Dependencies retain their own licenses. No newly copied third-party source was introduced in this review.

No historical throughput, trading return, quality, or queue-reduction figures are verified by these fixtures. Synthetic runs demonstrate behavior only. Current test results are in VALIDATION.md. GitHub Actions configuration exists; remote CI success requires an actual Actions run and is not implied by local tests.
