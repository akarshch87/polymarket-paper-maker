import tempfile
import unittest
from decimal import Decimal
from pathlib import Path

from polymarket_mm.replay import replay_session


class ReplayInputValidationTests(unittest.TestCase):
    def test_invalid_inputs_are_rejected_before_reading_session(self):
        cases = [
            (Decimal("0"), Decimal("0"), "baseline"),
            (Decimal("-1"), Decimal("0"), "baseline"),
            (Decimal("NaN"), Decimal("0"), "baseline"),
            (Decimal("100"), Decimal("-1"), "baseline"),
            (Decimal("100"), Decimal("Infinity"), "baseline"),
            (Decimal("100"), Decimal("0"), "unknown"),
        ]
        with tempfile.TemporaryDirectory() as directory:
            for capital, fee, strategy in cases:
                with self.subTest(capital=capital, fee=fee, strategy=strategy):
                    with self.assertRaises(ValueError):
                        replay_session(
                            Path(directory) / "missing", strategy, capital, Path(directory), fee
                        )


if __name__ == "__main__":
    unittest.main()
