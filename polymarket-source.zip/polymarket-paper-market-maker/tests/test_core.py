from decimal import Decimal

import pytest

from polymarket_mm.book.order_book import InvalidBook, OrderBook
from polymarket_mm.evaluation import side_adjusted_markout
from polymarket_mm.features import FeatureEngine
from polymarket_mm.models import Fill, Level
from polymarket_mm.portfolio import Portfolio
from polymarket_mm.simulation import PaperExchange, QueueModel
from polymarket_mm.strategy import make_quote


def seeded_book() -> OrderBook:
    book = OrderBook("yes")
    book.apply_snapshot(
        [Level(Decimal("0.40"), Decimal("10")), Level(Decimal("0.39"), Decimal("8"))],
        [Level(Decimal("0.50"), Decimal("12"))],
    )
    return book


def test_snapshot_and_best_prices() -> None:
    book = seeded_book()
    assert book.state.best_bid == Decimal("0.40")
    assert book.state.best_ask == Decimal("0.50")
    assert book.state.midpoint == Decimal("0.45")
    assert book.state.spread == Decimal("0.10")


def test_change_and_zero_delete() -> None:
    book = seeded_book()
    book.apply_change("BUY", Decimal("0.40"), Decimal("0"))
    assert book.state.best_bid == Decimal("0.39")


def test_crossed_book_is_rejected() -> None:
    with pytest.raises(InvalidBook):
        OrderBook("yes").apply_snapshot(
            [Level(Decimal("0.60"), Decimal("1"))], [Level(Decimal("0.50"), Decimal("1"))]
        )


def test_features_and_microprice() -> None:
    features = FeatureEngine().calculate(seeded_book())
    assert features is not None
    assert features.imbalance > 0
    assert features.microprice > features.midpoint


def test_quote_rounding_and_inventory_skew() -> None:
    book = seeded_book()
    features = FeatureEngine().calculate(book)
    assert features is not None
    neutral = make_quote("yes", features, inventory=Decimal("0"))
    long = make_quote("yes", features, inventory=Decimal("10"))
    assert long.bid < neutral.bid
    assert long.ask < neutral.ask
    assert long.ask > long.bid


def test_queue_model_requires_trade_through() -> None:
    exchange = PaperExchange(QueueModel(Decimal("1")))
    book = seeded_book()
    features = FeatureEngine().calculate(book)
    assert features is not None
    quote = make_quote("yes", features)
    exchange.submit(quote, Decimal("100"), Decimal("100"))
    assert exchange.consume_trade("yes", "SELL", quote.bid, Decimal("99")) == []
    assert exchange.consume_trade("yes", "SELL", quote.bid, Decimal("2"))


def test_portfolio_and_side_adjusted_markout() -> None:
    portfolio = Portfolio(Decimal("100"))
    fill = Fill("o", "yes", "BUY", Decimal("0.40"), Decimal("10"), seeded_book().state.timestamp)
    portfolio.apply_fill(fill)
    assert portfolio.cash == Decimal("96.00")
    assert portfolio.unrealized_pnl(Decimal("0.45")) == Decimal("0.50")
    assert side_adjusted_markout(fill, Decimal("0.45")) == Decimal("0.05")
