import pytest

from polymarket_mm.data.normalize import normalize_event


def test_book_envelope_normalization() -> None:
    rows = normalize_event(
        {
            "type": "book",
            "payload": {
                "asset_id": "yes",
                "timestamp": "2026-10-16T12:00:00Z",
                "bids": [{"price": "0.4", "size": "20"}],
                "asks": [{"price": "0.6", "size": "30"}],
            },
        }
    )
    assert rows[0]["type"] == "book"
    assert rows[0]["bids"] == [["0.4", "20"]]


def test_price_change_and_trade_envelope_normalization() -> None:
    rows = normalize_event(
        {
            "type": "price_change",
            "payload": {
                "timestamp": "2026-10-16T12:00:00Z",
                "price_changes": [{"asset_id": "yes", "side": "BUY", "price": "0.4", "size": "0"}],
            },
        }
    )
    assert rows[0]["size"] == "0"
    with pytest.raises(ValueError, match="size"):
        normalize_event(
            {
                "type": "last_trade_price",
                "payload": {
                    "asset_id": "yes",
                    "timestamp": "2026-10-16T12:00:00Z",
                    "price": "0.4",
                    "side": "SELL",
                },
            }
        )


def test_missing_time_is_not_invented_and_metadata_is_ignored() -> None:
    with pytest.raises(ValueError, match="timestamp"):
        normalize_event({"type": "book", "payload": {}})
    assert normalize_event({"type": "new_market", "payload": {}}) == []
