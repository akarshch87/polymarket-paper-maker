import json
from datetime import datetime, timezone
from decimal import Decimal as D
from pathlib import Path

import pytest

from polymarket_mm.book.order_book import InvalidBook, OrderBook
from polymarket_mm.models import Fill, Level, Quote
from polymarket_mm.portfolio import Portfolio
from polymarket_mm.replay import replay_session
from polymarket_mm.simulation import PaperExchange


def quote() -> Quote:
    return Quote("yes", D("0.4"), D("0.6"), D("10"), D("0.5"), "test")


def test_aggressor_side_does_not_fill_same_side() -> None:
    exchange = PaperExchange()
    exchange.submit(quote(), D("0"), D("0"))
    assert exchange.consume_trade("yes", "BUY", D("0.4"), D("100")) == []
    assert exchange.consume_trade("yes", "SELL", D("0.6"), D("100")) == []


def test_trade_volume_cannot_fill_multiple_orders_twice() -> None:
    exchange = PaperExchange()
    exchange.submit(quote(), D("0"), D("0"))
    exchange.submit(quote(), D("0"), D("0"))
    fills = exchange.consume_trade("yes", "SELL", D("0.4"), D("12"))
    assert sum(fill.size for fill in fills) == D("12")
    assert [fill.size for fill in fills] == [D("10"), D("2")]


def test_rejected_change_preserves_previous_valid_book() -> None:
    book = OrderBook("yes")
    book.apply_snapshot([Level(D("0.4"), D("10"))], [Level(D("0.6"), D("10"))])
    with pytest.raises(InvalidBook):
        book.apply_change("BUY", D("0.7"), D("10"))
    assert book.state.best_bid == D("0.4")
    with pytest.raises(InvalidBook):
        book.apply_change("UNKNOWN", D("0.5"), D("10"))


def test_short_cover_and_flip_accounting_reconcile() -> None:
    portfolio = Portfolio(D("100"))
    now = datetime.now(timezone.utc)
    portfolio.apply_fill(Fill("a", "yes", "SELL", D("0.6"), D("10"), now))
    assert portfolio.unrealized_pnl(D("0.5")) == D("1")
    portfolio.apply_fill(Fill("b", "yes", "BUY", D("0.4"), D("15"), now))
    assert portfolio.realized_pnl == D("2")
    assert portfolio.inventory == D("5")
    assert portfolio.cost_basis == D("2")
    assert portfolio.marked_value(D("0.5")) - D(
        "100"
    ) == portfolio.realized_pnl + portfolio.unrealized_pnl(D("0.5"))


def test_replay_uses_actual_events_and_fee_assumption(tmp_path: Path) -> None:
    fixture = Path(__file__).parents[1] / "examples" / "synthetic-session.jsonl"
    with_trades = replay_session(fixture, "baseline", D("10000"), tmp_path / "full", D("10"))
    no_trades = tmp_path / "no-trades.jsonl"
    no_trades.write_text(
        "\n".join(
            line for line in fixture.read_text().splitlines() if json.loads(line)["type"] != "trade"
        )
    )
    without = replay_session(no_trades, "baseline", D("10000"), tmp_path / "empty")
    assert with_trades["simulated_fills"] > 0
    assert without["simulated_fills"] == 0
    assert D(with_trades["fees"]) > 0
    assert with_trades["replayed_events"] == 5


def test_replay_rejects_raw_unknown_events(tmp_path: Path) -> None:
    session = tmp_path / "bad.jsonl"
    session.write_text(
        json.dumps({"type": "unknown", "token_id": "yes", "timestamp": "2026-10-16T12:00:00Z"})
    )
    with pytest.raises(ValueError, match="normalize"):
        replay_session(session, "baseline", D("10000"), tmp_path / "run")
