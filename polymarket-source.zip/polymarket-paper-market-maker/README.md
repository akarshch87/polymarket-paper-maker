# Polymarket Paper Market Maker

Real-time prediction-market paper trading engine for studying market making, inventory risk, simulated execution, and adverse selection on Polymarket.

> **Paper-only disclaimer:** this repository uses Polymarket public market data. It does not create an authenticated client, load a wallet, sign an order, or submit an order. The only execution object is an in-memory simulator. A live trading path would require deliberately adding a separate implementation and review boundary.

## Why I built it

Market making is a useful systems problem because a quote is a trade-off: a tighter quote may fill more often, but inventory and adverse selection can dominate the spread captured. This project makes those trade-offs explicit and replayable instead of claiming live profitability.

## Architecture

```mermaid
flowchart LR
  API[Polymarket public SDK] --> Discovery[Market discovery]
  API --> Stream[Async market stream]
  Stream --> Book[Local CLOB state]
  Book --> Features[Features]
  Features --> Fair[Fair value]
  Fair --> Quotes[Inventory-aware quotes]
  Quotes --> Sim[Paper exchange + queue model]
  Sim --> Portfolio[Paper portfolio/P&L]
  Portfolio --> Eval[Markouts + metrics]
  Stream --> Replay[JSONL recording/replay]
  Eval --> Reports[JSON/Markdown reports]
```

The current official Polymarket Python documentation names `polymarket-client` as the official SDK, uses `AsyncPublicClient` for public data, and exposes typed Decimal values and async realtime subscriptions. The adapter follows that interface and deliberately avoids the secure client.

## Features

- configurable active-market discovery through the official public SDK;
- reconnecting async stream adapter with exponential backoff and JSONL recording;
- Decimal-based local order books with crossed/stale-book protection;
- midpoint, spread, depth, imbalance, microprice, and rolling volatility;
- midpoint, microprice, and interpretable weighted fair-value modes;
- volatility- and inventory-aware two-sided quotes clamped to binary-market prices;
- optimistic and conservative queue-ahead models;
- partial fills, cancellations, paper cash/inventory, markouts, and reports;
- PostgreSQL schema for production-shaped persistence plus a tiny SQLite smoke store;
- deterministic synthetic paper run for reproducible tests without claiming live results.

## Setup

```powershell
# From the extracted project directory:
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
```

The repository's `pyproject.toml` pins compatible dependency ranges. No private key or wallet is needed.

## Commands

```powershell
polymm --help
polymm paper --strategy inventory-aware --starting-capital 10000
polymm discover --max-markets 5
polymm collect --token-id <public-token-id> --duration 60 --output artifacts/session.jsonl
polymm replay --session artifacts/session.jsonl --strategy baseline
polymm report --run artifacts/demo-run
```

`paper` is offline and deterministic. `discover` and `collect` require network access to Polymarket public services. `replay` consumes every supported normalized event in event-time order. It accepts one token per session, reconstructs book snapshots/changes, feeds trade prints to the paper exchange, and records actual simulated fills, markouts, fees, and drawdown for that session. Unsupported event schemas fail explicitly.

## Methodology

The ordinary order-book imbalance is `(bid_depth - ask_depth) / (bid_depth + ask_depth)`. The microprice weights the best ask by bid depth and the best bid by ask depth. Inventory skews both sides in the same direction: a long position makes the strategy less willing to buy and more willing to sell. A fill is not assumed merely because the market touched its price. The queue model first consumes estimated visible queue-ahead, then permits a partial or full fill from later trade volume.

Side-adjusted markout is `future_midpoint - fill_price` for a buy and the negative of that quantity for a sell. Positive means the hypothetical fill was favorable. Five-second, thirty-second, sixty-second, and five-minute buckets are part of the evaluation contract; a bucket is left null when the recorded data does not reach it.

Headline paper return is marked portfolio value minus starting cash, divided by starting cash. It is not a live return and is not an investment recommendation.

## Results

No live performance metric is included in this README. Run the deterministic command above to generate a local `metrics.json`; the report labels its synthetic data source. A real-data result should only be published after recording a session and replaying that exact session.

## Limitations

Public feeds do not reveal the hypothetical order's exact exchange queue priority. The simulator uses configurable approximations, does not model latency or cancellations by other participants, and cannot establish live profitability. Database persistence is represented by a PostgreSQL schema but the default demo is intentionally dependency-light. The live adapter depends on the current SDK interface and should be rechecked against official documentation when upgrading.

## Tests and structure

```powershell
pytest
ruff check .
ruff format --check .
mypy src
```

The main code is under `src/polymarket_mm/`: book state, features, strategy, simulation, portfolio, evaluation, data adapters, persistence, and CLI. Tests cover the pure market-making logic and never spend API money.

See [`docs/LEARNING_GUIDE.md`](docs/LEARNING_GUIDE.md), [`docs/METHODOLOGY.md`](docs/METHODOLOGY.md), [`docs/INTERVIEW_GUIDE.md`](docs/INTERVIEW_GUIDE.md), and [`docs/GIT_GUIDE.md`](docs/GIT_GUIDE.md) for the learning and workflow material.

## Reproducible session example

```powershell
python -m polymarket_mm.cli replay --session examples/synthetic-session.jsonl --strategy baseline --fee-bps 10 --output artifacts/replay-example
```

The five-event fixture is entirely synthetic. `collect` normalizes SDK book, price-change, and trade envelopes into this JSONL schema. Informational event types are ignored; missing timestamps or trade size are rejected. Split multi-token recordings before replay. Current adapter compatibility is checked against installed `polymarket-client` 0.10.0; the dependency is constrained to that minor series. The official SDK documentation was reviewed October 16, 2026: [Python SDK](https://docs.polymarket.com/getting-started/python).

Historical figures of 2.4 million updates, 25 markets, 8,400+ orders, 47% fill rate, 1.3% return, and 18% lower markout are unverified. No live result is claimed. This AI-assisted prototype is not recovered historical source behind those numbers.

`paper` runs the same event-driven replay engine on a built-in synthetic session; use `replay` to supply your own normalized session. The replay's `fill_rate` is unique orders receiving at least one fill divided by submitted orders; `simulated_fills` counts execution fragments. Optional `--fee-bps` is an explicit assumed fraction of fill notional, not a representation of a platform fee schedule. Zero is an assumption. See [methodology](docs/METHODOLOGY.md), [configuration](docs/CONFIGURATION.md), [provenance](docs/PROVENANCE.md), and [current validation](docs/VALIDATION.md).
