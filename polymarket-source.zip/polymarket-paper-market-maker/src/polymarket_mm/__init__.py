"""Paper-only Polymarket market-making research engine."""

__version__ = "0.1.0"
