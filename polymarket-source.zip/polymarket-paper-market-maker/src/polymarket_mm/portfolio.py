from __future__ import annotations

from decimal import Decimal

from polymarket_mm.models import Fill


class Portfolio:
    def __init__(self, starting_cash: Decimal) -> None:
        if starting_cash <= 0:
            raise ValueError("starting cash must be positive")
        self.starting_cash = starting_cash
        self.cash = starting_cash
        self.inventory = Decimal("0")
        self.cost_basis = Decimal("0")
        self.realized_pnl = Decimal("0")
        self.max_inventory = Decimal("0")

    def apply_fill(self, fill: Fill) -> None:
        if fill.size <= 0 or not 0 < fill.price < 1:
            raise ValueError("fill size must be positive and price must be in (0, 1)")
        signed_size = fill.size if fill.side == "BUY" else -fill.size
        self.cash -= signed_size * fill.price
        previous = self.inventory
        average_cost = self.cost_basis / previous if previous else Decimal("0")
        if previous == 0 or previous * signed_size > 0:
            self.cost_basis += signed_size * fill.price
        else:
            closing = min(abs(previous), fill.size)
            direction = Decimal("1") if previous > 0 else Decimal("-1")
            self.realized_pnl += direction * (fill.price - average_cost) * closing
            remaining = previous + signed_size
            if remaining * previous < 0:
                self.cost_basis = remaining * fill.price
            else:
                self.cost_basis = remaining * average_cost
        self.inventory += signed_size
        self.max_inventory = max(self.max_inventory, abs(self.inventory))

    def marked_value(self, midpoint: Decimal) -> Decimal:
        return self.cash + self.inventory * midpoint

    def unrealized_pnl(self, midpoint: Decimal) -> Decimal:
        return self.inventory * midpoint - self.cost_basis

    def return_on_starting_capital(self, midpoint: Decimal) -> Decimal:
        return (self.marked_value(midpoint) - self.starting_cash) / self.starting_cash
