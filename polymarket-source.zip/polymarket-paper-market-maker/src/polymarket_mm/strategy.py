from __future__ import annotations

from decimal import ROUND_DOWN, ROUND_UP, Decimal

from polymarket_mm.models import MarketFeatures, Quote


def fair_value(
    features: MarketFeatures, mode: str = "microprice", imbalance_weight: Decimal = Decimal("0.25")
) -> Decimal:
    if mode == "midpoint":
        return features.midpoint
    if mode == "microprice":
        return features.microprice
    if mode == "weighted":
        return features.midpoint + imbalance_weight * features.spread * features.imbalance
    raise ValueError(f"unknown fair-value mode: {mode}")


def _round_tick(price: Decimal, tick: Decimal, rounding: str) -> Decimal:
    return (price / tick).quantize(Decimal("1"), rounding=rounding) * tick


def make_quote(
    token_id: str,
    features: MarketFeatures,
    inventory: Decimal = Decimal("0"),
    tick_size: Decimal = Decimal("0.01"),
    base_half_spread: Decimal = Decimal("0.02"),
    inventory_coefficient: Decimal = Decimal("0.01"),
    size: Decimal = Decimal("10"),
    fair_value_mode: str = "microprice",
) -> Quote:
    if not Decimal("0") < tick_size < Decimal("1"):
        raise ValueError("tick size must be between zero and one")
    fv = fair_value(features, fair_value_mode)
    half = base_half_spread + features.volatility
    skew = inventory * inventory_coefficient
    bid = _round_tick(fv - half - skew, tick_size, ROUND_DOWN)
    ask = _round_tick(fv + half - skew, tick_size, ROUND_UP)
    bid = max(tick_size, min(Decimal("0.99"), bid))
    ask = max(tick_size, min(Decimal("0.99"), ask))
    if ask <= bid:
        ask = min(Decimal("0.99"), bid + tick_size)
    return Quote(
        token_id, bid, ask, size, fv, "volatility and inventory-aware two-sided paper quote"
    )
