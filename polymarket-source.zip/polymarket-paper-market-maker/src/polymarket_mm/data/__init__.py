"""Official-SDK adapters and replayable market-data envelopes."""
