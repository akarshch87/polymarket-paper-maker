"""Normalize tested public SDK 0.10 event envelopes without execution access."""

from __future__ import annotations

from typing import Any


def normalize_event(event: dict[str, Any]) -> list[dict[str, Any]]:
    kind, payload = event.get("type"), event.get("payload", {})
    if kind not in {"book", "price_change", "last_trade_price"}:
        return []
    timestamp = payload.get("timestamp")
    if not timestamp:
        raise ValueError("public event has no event-time timestamp")
    if kind == "price_change":
        return [
            {
                "type": "change",
                "token_id": str(change["asset_id"]),
                "timestamp": timestamp,
                "side": change["side"],
                "price": str(change["price"]),
                "size": str(change["size"]),
            }
            for change in payload["price_changes"]
        ]
    base = {"token_id": str(payload["asset_id"]), "timestamp": timestamp}
    if kind == "book":
        return [
            {
                **base,
                "type": "book",
                "bids": [[str(level["price"]), str(level["size"])] for level in payload["bids"]],
                "asks": [[str(level["price"]), str(level["size"])] for level in payload["asks"]],
            }
        ]
    if payload.get("size") is None:
        raise ValueError("public trade has no size; cannot infer a paper fill")
    return [
        {
            **base,
            "type": "trade",
            "side": payload["side"],
            "price": str(payload["price"]),
            "size": str(payload["size"]),
        }
    ]
