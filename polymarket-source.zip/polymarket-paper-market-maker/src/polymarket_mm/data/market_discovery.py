from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any, cast


@dataclass(frozen=True)
class MarketCandidate:
    market_id: str
    question: str
    token_ids: tuple[str, ...]
    active: bool
    volume: Decimal
    liquidity: Decimal
    tick_size: Decimal | None
    minimum_order_size: Decimal | None
    raw: dict[str, Any]


def select_markets(
    markets: list[MarketCandidate], max_markets: int, min_volume: Decimal, min_liquidity: Decimal
) -> list[MarketCandidate]:
    eligible = [
        m
        for m in markets
        if m.active
        and m.volume >= min_volume
        and m.liquidity >= min_liquidity
        and len(m.token_ids) >= 1
    ]
    return sorted(eligible, key=lambda m: (m.liquidity, m.volume), reverse=True)[:max_markets]


async def fetch_active_markets(
    max_markets: int = 5, min_volume: Decimal = Decimal("0"), min_liquidity: Decimal = Decimal("0")
) -> list[MarketCandidate]:
    """Read public market data through the current official polymarket-client SDK.

    Importing lazily keeps deterministic tests independent of network packages.
    """
    from polymarket import AsyncPublicClient

    def dump(value: Any) -> dict[str, Any]:
        if hasattr(value, "model_dump"):
            return cast(dict[str, Any], value.model_dump())
        return dict(vars(value))

    candidates: list[MarketCandidate] = []
    async with AsyncPublicClient() as client:
        pages = client.list_markets(closed=False)
        async for market in pages.iter_items():
            raw = dump(market)
            state = getattr(market, "state", None)
            outcomes = getattr(market, "outcomes", None)
            metrics = getattr(market, "metrics", None)
            trading = getattr(market, "trading", None)
            token_ids = tuple(
                str(token_id)
                for token_id in (
                    getattr(getattr(outcomes, "yes", None), "token_id", None),
                    getattr(getattr(outcomes, "no", None), "token_id", None),
                )
                if token_id is not None
            )
            candidates.append(
                MarketCandidate(
                    market_id=str(getattr(market, "id", raw.get("id", ""))),
                    question=str(getattr(market, "question", raw.get("question", "")) or ""),
                    token_ids=token_ids,
                    active=bool(getattr(state, "active", raw.get("active", True))),
                    volume=Decimal(str(getattr(metrics, "volume", raw.get("volume", "0")) or "0")),
                    liquidity=Decimal(
                        str(getattr(metrics, "liquidity", raw.get("liquidity", "0")) or "0")
                    ),
                    tick_size=(
                        Decimal(str(getattr(trading, "minimum_tick_size", "")))
                        if getattr(trading, "minimum_tick_size", None) is not None
                        else None
                    ),
                    minimum_order_size=(
                        Decimal(str(getattr(trading, "minimum_order_size", "")))
                        if getattr(trading, "minimum_order_size", None) is not None
                        else None
                    ),
                    raw=raw,
                )
            )
            if len(candidates) >= max_markets * 20:
                break
    return select_markets(candidates, max_markets, min_volume, min_liquidity)
