from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

from polymarket_mm.data.normalize import normalize_event

logger = logging.getLogger(__name__)


async def stream_market_events(
    token_ids: list[str], stop_after: float | None = None
) -> AsyncIterator[dict[str, Any]]:
    """Yield normalized public events with reconnect/backoff behavior.

    The SDK owns the WebSocket transport and schema. This adapter owns lifecycle,
    reconnect accounting, and the replay-friendly JSON envelope.
    """
    from polymarket import AsyncPublicClient
    from polymarket.streams import MarketSpec

    started = asyncio.get_running_loop().time()
    backoff = 1.0
    while stop_after is None or asyncio.get_running_loop().time() - started < stop_after:
        try:
            async with AsyncPublicClient() as client:
                async with await client.subscribe(MarketSpec(asset_ids=token_ids)) as stream:
                    backoff = 1.0
                    async for event in stream:
                        raw = (
                            event.model_dump(mode="json")
                            if hasattr(event, "model_dump")
                            else json.loads(json.dumps(event, default=str))
                        )
                        yield raw
                        if (
                            stop_after is not None
                            and asyncio.get_running_loop().time() - started >= stop_after
                        ):
                            return
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("market stream disconnected; retrying")
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 30.0)


async def collect_jsonl(path: str, token_ids: list[str], duration: float) -> int:
    if duration <= 0:
        raise ValueError("duration must be positive")
    count = 0
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        try:
            async with asyncio.timeout(duration):
                async for event in stream_market_events(token_ids, duration):
                    for normalized in normalize_event(event):
                        handle.write(json.dumps(normalized, sort_keys=True) + "\n")
                        count += 1
        except TimeoutError:
            pass
    return count
