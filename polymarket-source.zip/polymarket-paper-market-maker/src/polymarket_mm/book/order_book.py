from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal

from polymarket_mm.models import BookSnapshot, Level


class InvalidBook(ValueError):
    """Raised when a snapshot is crossed or contains invalid levels."""


class OrderBook:
    """Mutable CLOB state reconstructed from snapshots and price changes."""

    def __init__(self, token_id: str, tick_size: Decimal = Decimal("0.01")) -> None:
        self.state = BookSnapshot(token_id=token_id, tick_size=tick_size)

    def apply_snapshot(
        self,
        bids: list[Level],
        asks: list[Level],
        timestamp: datetime | None = None,
        tick_size: Decimal | None = None,
        last_trade: Decimal | None = None,
    ) -> None:
        if any(level.size < 0 for level in [*bids, *asks]):
            raise InvalidBook("level size cannot be negative")
        new_bids = {level.price: level.size for level in bids if level.size > 0}
        new_asks = {level.price: level.size for level in asks if level.size > 0}
        self._validate(new_bids, new_asks)
        self.state.bids = new_bids
        self.state.asks = new_asks
        self.state.timestamp = timestamp or datetime.now(timezone.utc)
        if tick_size is not None:
            self.state.tick_size = tick_size
        self.state.last_trade = last_trade

    def apply_change(
        self, side: str, price: Decimal, size: Decimal, timestamp: datetime | None = None
    ) -> None:
        if side.upper() not in {"BUY", "BID", "SELL", "ASK"}:
            raise InvalidBook("unknown order-book side")
        bids, asks = self.state.bids.copy(), self.state.asks.copy()
        book = bids if side.upper() in {"BUY", "BID"} else asks
        if size == 0:
            book.pop(price, None)
        elif size < 0:
            raise InvalidBook("level size cannot be negative")
        else:
            book[price] = size
        self._validate(bids, asks)
        self.state.bids, self.state.asks = bids, asks
        self.state.timestamp = timestamp or datetime.now(timezone.utc)

    def is_stale(self, now: datetime, stale_after_seconds: float) -> bool:
        return (now - self.state.timestamp).total_seconds() > stale_after_seconds

    def top_depth(self, side: str, levels: int = 5) -> Decimal:
        prices = sorted(
            (self.state.bids if side == "BUY" else self.state.asks),
            reverse=side == "BUY",
        )[:levels]
        book = self.state.bids if side == "BUY" else self.state.asks
        return sum((book[p] for p in prices), Decimal("0"))

    @staticmethod
    def _validate(bids: dict[Decimal, Decimal], asks: dict[Decimal, Decimal]) -> None:
        if any(price <= 0 or price >= 1 for price in (*bids, *asks)):
            raise InvalidBook("binary-market prices must be between 0 and 1")
        if bids and asks and max(bids) >= min(asks):
            raise InvalidBook("crossed order book")
