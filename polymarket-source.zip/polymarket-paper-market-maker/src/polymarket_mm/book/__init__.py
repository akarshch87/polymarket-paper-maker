"""Maintained local order-book state."""
