from polymarket_mm.cli.main import main

main()
