from __future__ import annotations

import argparse
import asyncio
import json
import logging
from decimal import Decimal
from pathlib import Path

from polymarket_mm.data.market_discovery import fetch_active_markets
from polymarket_mm.data.stream import collect_jsonl
from polymarket_mm.replay import replay_session


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="polymm", description="Paper-only Polymarket research CLI"
    )
    sub = parser.add_subparsers(dest="command", required=True)
    discover = sub.add_parser(
        "discover", help="discover active markets through the official public SDK"
    )
    discover.add_argument("--max-markets", type=int, default=5)
    discover.add_argument("--min-volume", type=Decimal, default=Decimal("0"))
    discover.add_argument("--min-liquidity", type=Decimal, default=Decimal("0"))
    collect = sub.add_parser("collect", help="record a public WebSocket session as JSONL")
    collect.add_argument("--token-id", action="append", required=True)
    collect.add_argument("--duration", type=float, default=30)
    collect.add_argument("--output", type=Path, default=Path("artifacts/session.jsonl"))
    paper = sub.add_parser("paper", help="run a deterministic paper-trading smoke run")
    paper.add_argument(
        "--strategy", choices=["baseline", "inventory-aware"], default="inventory-aware"
    )
    paper.add_argument("--starting-capital", type=Decimal, default=Decimal("10000"))
    paper.add_argument("--output", type=Path, default=Path("artifacts/demo-run"))
    replay = sub.add_parser("replay", help="replay a recorded JSONL session deterministically")
    replay.add_argument("--session", type=Path, required=True)
    replay.add_argument(
        "--strategy", choices=["baseline", "inventory-aware"], default="inventory-aware"
    )
    replay.add_argument("--output", type=Path, default=Path("artifacts/replay-run"))
    replay.add_argument("--starting-capital", type=Decimal, default=Decimal("10000"))
    replay.add_argument("--fee-bps", type=Decimal, default=Decimal("0"))
    report = sub.add_parser("report", help="print a generated metrics file")
    report.add_argument("--run", type=Path, required=True)
    return parser


SYNTHETIC_SESSION = '{"type":"book","token_id":"synthetic-yes","timestamp":"2026-10-16T12:00:00Z","bids":[["0.48","100"]],"asks":[["0.52","100"]]}\n{"type":"trade","token_id":"synthetic-yes","timestamp":"2026-10-16T12:00:01Z","side":"SELL","price":"0.48","size":"110"}\n{"type":"book","token_id":"synthetic-yes","timestamp":"2026-10-16T12:00:10Z","bids":[["0.49","100"]],"asks":[["0.53","100"]]}\n{"type":"trade","token_id":"synthetic-yes","timestamp":"2026-10-16T12:00:11Z","side":"BUY","price":"0.60","size":"150"}\n{"type":"book","token_id":"synthetic-yes","timestamp":"2026-10-16T12:05:20Z","bids":[["0.49","100"]],"asks":[["0.53","100"]]}\n'


def run_paper(strategy: str, starting_capital: Decimal, output: Path) -> dict[str, object]:
    """Run the same event-driven engine on an explicitly synthetic built-in session."""
    output.mkdir(parents=True, exist_ok=True)
    session = output / "synthetic-session.jsonl"
    session.write_text(SYNTHETIC_SESSION, encoding="utf-8")
    return replay_session(session, strategy, starting_capital, output)


async def _async_main(args: argparse.Namespace) -> int:
    if args.command == "discover":
        markets = await fetch_active_markets(args.max_markets, args.min_volume, args.min_liquidity)
        print(json.dumps([m.raw for m in markets], indent=2, default=str))
    elif args.command == "collect":
        count = await collect_jsonl(str(args.output), args.token_id, args.duration)
        print(json.dumps({"events_recorded": count, "output": str(args.output)}))
    return 0


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    args = build_parser().parse_args()
    # Offline commands should not initialize a network-capable event loop.
    if args.command == "paper":
        print(json.dumps(run_paper(args.strategy, args.starting_capital, args.output), indent=2))
    elif args.command == "replay":
        print(
            json.dumps(
                replay_session(
                    args.session, args.strategy, args.starting_capital, args.output, args.fee_bps
                ),
                indent=2,
            )
        )
    elif args.command == "report":
        print((args.run / "metrics.json").read_text(encoding="utf-8"))
    else:
        raise SystemExit(asyncio.run(_async_main(args)))


if __name__ == "__main__":
    main()
