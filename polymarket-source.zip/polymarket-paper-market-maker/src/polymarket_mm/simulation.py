from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from uuid import uuid4

from polymarket_mm.models import Fill, PaperOrder, Quote, Side


class QueueModel:
    """Conservative observable approximation; exact exchange priority is unknowable."""

    def __init__(self, participation: Decimal) -> None:
        if not Decimal("0") < participation <= Decimal("1"):
            raise ValueError("participation must be in (0, 1]")
        self.participation = participation

    def queue_ahead(self, visible_size: Decimal) -> Decimal:
        return visible_size * self.participation


OPTIMISTIC_QUEUE = QueueModel(Decimal("0.25"))
CONSERVATIVE_QUEUE = QueueModel(Decimal("1.0"))


class PaperExchange:
    """A fill simulator. It can never place a network order or authenticate a wallet."""

    def __init__(self, queue_model: QueueModel = CONSERVATIVE_QUEUE) -> None:
        self.queue_model = queue_model
        self.orders: dict[str, PaperOrder] = {}
        self.fills: list[Fill] = []

    def submit(self, quote: Quote, visible_bid: Decimal, visible_ask: Decimal) -> list[PaperOrder]:
        now = datetime.now(timezone.utc)
        orders = [
            PaperOrder(
                str(uuid4()),
                quote.token_id,
                "BUY",
                quote.bid,
                quote.size,
                quote.size,
                now,
                self.queue_model.queue_ahead(visible_bid),
            ),
            PaperOrder(
                str(uuid4()),
                quote.token_id,
                "SELL",
                quote.ask,
                quote.size,
                quote.size,
                now,
                self.queue_model.queue_ahead(visible_ask),
            ),
        ]
        for order in orders:
            self.orders[order.order_id] = order
        return orders

    def consume_trade(
        self,
        token_id: str,
        side: Side,
        price: Decimal,
        size: Decimal,
        timestamp: datetime | None = None,
    ) -> list[Fill]:
        """Consume prints that reach our price; queue ahead is consumed first."""
        if side not in {"BUY", "SELL"} or size < 0 or not 0 < price < 1:
            raise ValueError("trade requires a valid aggressor side, price and nonnegative size")
        output: list[Fill] = []
        remaining_volume = size
        candidates = sorted(
            self.orders.values(),
            key=lambda order: (
                order.price if side == "BUY" else -order.price,
                order.submitted_at,
            ),
        )
        for order in candidates:
            if remaining_volume <= 0:
                break
            if order.status != "OPEN" or order.token_id != token_id or order.side == side:
                continue
            reached = (order.side == "BUY" and price <= order.price) or (
                order.side == "SELL" and price >= order.price
            )
            if not reached:
                continue
            consumed_queue = min(remaining_volume, order.queue_ahead)
            order.queue_ahead -= consumed_queue
            remaining_volume -= consumed_queue
            filled = min(order.remaining, remaining_volume)
            if filled <= 0:
                continue
            order.remaining -= filled
            remaining_volume -= filled
            if order.remaining == 0:
                order.status = "FILLED"
            fill = Fill(
                order.order_id,
                order.token_id,
                order.side,
                order.price,
                filled,
                timestamp or datetime.now(timezone.utc),
            )
            self.fills.append(fill)
            output.append(fill)
        return output

    def cancel(self, order_id: str) -> None:
        order = self.orders[order_id]
        if order.status == "OPEN":
            order.status = "CANCELLED"
