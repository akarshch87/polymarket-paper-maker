from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

POSTGRES_SCHEMA = Path(__file__).resolve().parents[2] / "schema.sql"


def write_run_artifacts(output_dir: Path, metrics: dict[str, Any], report: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "metrics.json").write_text(
        json.dumps(metrics, indent=2, default=str) + "\n", encoding="utf-8"
    )
    (output_dir / "report.md").write_text(report, encoding="utf-8")


def initialize_sqlite(path: Path) -> None:
    """Tiny local smoke-test store; production persistence is PostgreSQL via schema.sql."""
    with sqlite3.connect(path) as connection:
        connection.executescript("""
        CREATE TABLE IF NOT EXISTS strategy_runs (run_id TEXT PRIMARY KEY, started_at TEXT NOT NULL, metrics_json TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS market_events (run_id TEXT NOT NULL, event_ts TEXT NOT NULL, payload_json TEXT NOT NULL);
        """)
