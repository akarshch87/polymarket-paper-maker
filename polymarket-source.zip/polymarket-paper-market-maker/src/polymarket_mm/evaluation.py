from __future__ import annotations

from decimal import Decimal

from polymarket_mm.models import Fill


def side_adjusted_markout(fill: Fill, future_midpoint: Decimal) -> Decimal:
    raw = future_midpoint - fill.price
    return raw if fill.side == "BUY" else -raw


def markout_summary(
    fill: Fill, future_midpoints: dict[int, Decimal | None]
) -> dict[str, Decimal | None]:
    return {
        f"{seconds}s": (side_adjusted_markout(fill, midpoint) if midpoint is not None else None)
        for seconds, midpoint in future_midpoints.items()
    }


def mean_markouts(rows: list[dict[str, Decimal | None]]) -> dict[str, Decimal | None]:
    result: dict[str, Decimal | None] = {}
    for key in {key for row in rows for key in row}:
        values: list[Decimal] = [value for row in rows if (value := row.get(key)) is not None]
        result[key] = sum(values, Decimal("0")) / len(values) if values else None
    return result
