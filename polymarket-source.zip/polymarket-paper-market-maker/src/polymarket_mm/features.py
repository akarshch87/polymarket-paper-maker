from __future__ import annotations

from collections import deque
from decimal import Decimal
from typing import cast

from polymarket_mm.book.order_book import OrderBook
from polymarket_mm.models import MarketFeatures


class FeatureEngine:
    def __init__(self, lookback: int = 20) -> None:
        self.prices: deque[Decimal] = deque(maxlen=lookback)

    def calculate(self, book: OrderBook, levels: int = 5) -> MarketFeatures | None:
        midpoint = book.state.midpoint
        spread = book.state.spread
        if midpoint is None or spread is None or book.state.tick_size <= 0:
            return None
        bid_depth = book.top_depth("BUY", levels)
        ask_depth = book.top_depth("SELL", levels)
        total = bid_depth + ask_depth
        imbalance = (bid_depth - ask_depth) / total if total else Decimal("0")
        bid = book.state.best_bid or midpoint
        ask = book.state.best_ask or midpoint
        microprice = ((ask * bid_depth) + (bid * ask_depth)) / total if total else midpoint
        self.prices.append(midpoint)
        volatility = self._volatility()
        return MarketFeatures(
            midpoint=midpoint,
            spread=spread,
            spread_ticks=spread / book.state.tick_size,
            bid_depth=bid_depth,
            ask_depth=ask_depth,
            imbalance=imbalance,
            weighted_imbalance=imbalance,
            microprice=microprice,
            volatility=volatility,
            update_intensity=Decimal(len(self.prices)),
        )

    def _volatility(self) -> Decimal:
        if len(self.prices) < 2:
            return Decimal("0")
        changes = [self.prices[i] - self.prices[i - 1] for i in range(1, len(self.prices))]
        mean = sum(changes, Decimal("0")) / len(changes)
        variance = sum((change - mean) * (change - mean) for change in changes) / len(changes)
        return cast(Decimal, variance).sqrt()
