from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Literal

Side = Literal["BUY", "SELL"]


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class Level:
    price: Decimal
    size: Decimal


@dataclass
class BookSnapshot:
    token_id: str
    bids: dict[Decimal, Decimal] = field(default_factory=dict)
    asks: dict[Decimal, Decimal] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=utc_now)
    tick_size: Decimal = Decimal("0.01")
    last_trade: Decimal | None = None

    @property
    def best_bid(self) -> Decimal | None:
        return max(self.bids) if self.bids else None

    @property
    def best_ask(self) -> Decimal | None:
        return min(self.asks) if self.asks else None

    @property
    def midpoint(self) -> Decimal | None:
        if self.best_bid is None or self.best_ask is None:
            return None
        return (self.best_bid + self.best_ask) / 2

    @property
    def spread(self) -> Decimal | None:
        if self.best_bid is None or self.best_ask is None:
            return None
        return self.best_ask - self.best_bid


@dataclass(frozen=True)
class MarketFeatures:
    midpoint: Decimal
    spread: Decimal
    spread_ticks: Decimal
    bid_depth: Decimal
    ask_depth: Decimal
    imbalance: Decimal
    weighted_imbalance: Decimal
    microprice: Decimal
    volatility: Decimal
    update_intensity: Decimal


@dataclass(frozen=True)
class Quote:
    token_id: str
    bid: Decimal
    ask: Decimal
    size: Decimal
    fair_value: Decimal
    reason: str


@dataclass
class PaperOrder:
    order_id: str
    token_id: str
    side: Side
    price: Decimal
    size: Decimal
    remaining: Decimal
    submitted_at: datetime
    queue_ahead: Decimal
    status: str = "OPEN"


@dataclass(frozen=True)
class Fill:
    order_id: str
    token_id: str
    side: Side
    price: Decimal
    size: Decimal
    timestamp: datetime


@dataclass(frozen=True)
class RunMetrics:
    runtime_seconds: float
    markets_monitored: int
    order_book_updates: int
    simulated_orders: int
    simulated_fills: int
    fill_rate: float
    realized_pnl: Decimal
    unrealized_pnl: Decimal
    paper_return: float
    max_drawdown: Decimal
    max_inventory: Decimal
    mean_5s_markout: Decimal | None
    mean_30s_markout: Decimal | None
    mean_5m_markout: Decimal | None
