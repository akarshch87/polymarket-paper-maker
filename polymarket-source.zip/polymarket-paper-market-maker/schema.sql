CREATE TABLE IF NOT EXISTS markets (
  market_id TEXT PRIMARY KEY, event_id TEXT, question TEXT NOT NULL, token_ids JSONB NOT NULL,
  active BOOLEAN NOT NULL, tick_size NUMERIC, minimum_order_size NUMERIC, discovered_at TIMESTAMPTZ NOT NULL
);
CREATE TABLE IF NOT EXISTS market_events (
  id BIGSERIAL PRIMARY KEY, market_id TEXT NOT NULL, token_id TEXT, event_type TEXT NOT NULL,
  event_ts TIMESTAMPTZ NOT NULL, payload JSONB NOT NULL
);
CREATE TABLE IF NOT EXISTS strategy_runs (
  run_id TEXT PRIMARY KEY, strategy TEXT NOT NULL, started_at TIMESTAMPTZ NOT NULL,
  finished_at TIMESTAMPTZ, starting_capital NUMERIC NOT NULL, metrics JSONB
);
CREATE TABLE IF NOT EXISTS quotes (
  id BIGSERIAL PRIMARY KEY, run_id TEXT REFERENCES strategy_runs(run_id), token_id TEXT NOT NULL,
  quote_ts TIMESTAMPTZ NOT NULL, fair_value NUMERIC NOT NULL, bid NUMERIC NOT NULL, ask NUMERIC NOT NULL, size NUMERIC NOT NULL
);
CREATE TABLE IF NOT EXISTS paper_orders (
  order_id TEXT PRIMARY KEY, run_id TEXT REFERENCES strategy_runs(run_id), token_id TEXT NOT NULL,
  side TEXT NOT NULL, price NUMERIC NOT NULL, size NUMERIC NOT NULL, queue_ahead NUMERIC NOT NULL, status TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS paper_fills (
  id BIGSERIAL PRIMARY KEY, order_id TEXT REFERENCES paper_orders(order_id), fill_ts TIMESTAMPTZ NOT NULL,
  price NUMERIC NOT NULL, size NUMERIC NOT NULL
);
CREATE TABLE IF NOT EXISTS inventory_snapshots (
  id BIGSERIAL PRIMARY KEY, run_id TEXT REFERENCES strategy_runs(run_id), snapshot_ts TIMESTAMPTZ NOT NULL,
  inventory NUMERIC NOT NULL, cash NUMERIC NOT NULL, marked_value NUMERIC NOT NULL
);
