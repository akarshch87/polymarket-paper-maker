# Polymarket Paper Market Maker

Real-time prediction-market paper trading engine for studying market making, inventory risk, simulated execution, and adverse selection on Polymarket.

> **Paper-only disclaimer:** this repository uses Polymarket public market data. It does not create an authenticated client, load a wallet, sign an order, or submit an order. The only execution object is an in-memory simulator. A live trading path would require deliberately adding a separate implementation and review boundary.

## Why I built it

Market making is a useful systems problem because a quote is a trade-off: a tighter quote may fill more often, but inventory and adverse selection can dominate the spread captured. This project makes those trade-offs explicit and replayable instead of claiming live profitability.

## Architecture

```mermaid
flowchart LR
  API[Polymarket public SDK] --> Discovery[Market discovery]
  API --> Stream[Async market stream]
  Stream --> Book[Local CLOB state]
  Book --> Features[Features]
  Features --> Fair[Fair value]
  Fair --> Quotes[Inventory-aware quotes]
  Quotes --> Sim[Paper exchange + queue model]
  Sim --> Portfolio[Paper portfolio/P&L]
  Portfolio --> Eval[Markouts + metrics]
  Stream --> Replay[JSONL recording/replay]
  Eval --> Reports[JSON/Markdown reports]
```

The current official Polymarket Python documentation names `polymarket-client` as the official SDK, uses `AsyncPublicClient` for public data, and exposes typed Decimal values and async realtime subscriptions. The adapter follows that interface and deliberately avoids the secure client.

## Features

- configurable active-market discovery through the official public SDK;
- reconnecting async stream adapter with exponential backoff and JSONL recording;
- Decimal-based local order books with crossed/stale-book protection;
- midpoint, spread, depth, imbalance, microprice, and rolling volatility;
- midpoint, microprice, and interpretable weighted fair-value modes;
- volatility- and inventory-aware two-sided quotes clamped to binary-market prices;
- optimistic and conservative queue-ahead models;
- partial fills, cancellations, paper cash/inventory, markouts, and reports;
- PostgreSQL schema for production-shaped persistence plus a tiny SQLite smoke store;
- deterministic synthetic paper run for reproducible tests without claiming live results.

## Setup

```powershell
# From the extracted project directory:
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
```

The repository's `pyproject.toml` pins compatible dependency ranges. No private key or wallet is needed.

## Commands

```powershell
polymm --help
polymm paper --strategy inventory-aware --starting-capital 10000
polymm discover --max-markets 5
polymm collect --token-id <public-token-id> --duration 60 --output artifacts/session.jsonl
polymm replay --session examples/synthetic-session.jsonl --strategy baseline
polymm report --run artifacts/demo-run
```

`paper` is offline and deterministic. `discover` and `collect` require network access to Polymarket public services. `replay` consumes every supported normalized event in event-time order. It accepts one token per session, reconstructs book snapshots/changes, feeds trade prints to the paper exchange, and records actual simulated fills, markouts, fees, and drawdown for that session. Unsupported event schemas fail explicitly.

## Methodology

The ordinary order-book imbalance is `(bid_depth - ask_depth) / (bid_depth + ask_depth)`. The microprice weights the best ask by bid depth and the best bid by ask depth. Inventory skews both sides in the same direction: a long position makes the strategy less willing to buy and more willing to sell. A fill is not assumed merely because the market touched its price. The queue model first consumes estimated visible queue-ahead, then permits a partial or full fill from later trade volume.

Side-adjusted markout is `future_midpoint - fill_price` for a buy and the negative of that quantity for a sell. Positive means the hypothetical fill was favorable. Five-second, thirty-second, sixty-second, and five-minute buckets are part of the evaluation contract; a bucket is left null when the recorded data does not reach it.

Headline paper return is marked portfolio value minus starting cash, divided by starting cash. It is not a live return and is not an investment recommendation.

## Results

No live performance metric is included in this README. Run the deterministic command above to generate a local `metrics.json`; the report labels its synthetic data source. A real-data result should only be published after recording a session and replaying that exact session.

## Limitations

Public feeds do not reveal the hypothetical order's exact exchange queue priority. The simulator uses configurable approximations, does not model latency or cancellations by other participants, and cannot establish live profitability. Database persistence is represented by a PostgreSQL schema but the default demo is intentionally dependency-light. The live adapter depends on the current SDK interface and should be rechecked against official documentation when upgrading.

## Tests and structure

```powershell
pytest
ruff check .
ruff format --check .
mypy src
```

The main code is under `src/polymarket_mm/`: book state, features, strategy, simulation, portfolio, evaluation, data adapters, persistence, and CLI. Tests cover the pure market-making logic and never spend API money.

See [`docs/LEARNING_GUIDE.md`](docs/LEARNING_GUIDE.md), [`docs/METHODOLOGY.md`](docs/METHODOLOGY.md), and [`docs/GIT_GUIDE.md`](docs/GIT_GUIDE.md) for further details.

## Reproducible session example

```powershell
python -m polymarket_mm.cli replay --session examples/synthetic-session.jsonl --strategy baseline --fee-bps 10 --output artifacts/replay-example
```

The five event fixture is entirely synthetic. `collect` normalizes SDK book, price change, tick change, and trade envelopes into this JSONL schema and refuses to overwrite existing recordings. Informational event types are ignored; missing timestamps or trade size are rejected. Split multi token recordings before replay. Collected trade sides are labeled unspecified and replay stops until their aggressor meaning has been independently verified and the input marked accordingly. Explicit synthetic inputs treat side as aggressor direction. Current adapter compatibility was checked against installed `polymarket-client` 0.10.0; no new live collection was performed in this review. See the [market channel reference](https://docs.polymarket.com/api-reference/wss/market).

`paper` runs the same event-driven replay engine on a built-in synthetic session; use `replay` to supply your own normalized session. The replay's `fill_rate` is unique orders receiving at least one fill divided by submitted orders; `simulated_fills` counts execution fragments. Optional `--fee-bps` is an explicit assumed fraction of fill notional, not a representation of a platform fee schedule. Zero is an assumption. See [methodology](docs/METHODOLOGY.md), [configuration](docs/CONFIGURATION.md), and [current validation](docs/VALIDATION.md).

## Compare generated sessions

Run both strategies on the same seeded fictional data:

```powershell
polymm compare --output artifacts/study --seed 20261118 --sessions 44 --steps 250
polymm compare --output artifacts/adverse --seed 71201 --sessions 16 --steps 200 --scenario adverse --fee-bps 25
```

This creates 44 sessions with 11,000 book events and 11,000 trade events.
The output contains the generated input, a report for each strategy, and a
summary of the differences. Choose a new output directory for each run. The
generator models a simple random walk and assumed trade flow. The adverse scenario links the next price movement to the preceding trade direction. The fee is an explicit assumption and not a current exchange fee quote. The generator does not model market impact or establish trading performance.

Replay starts with cash and no tokens, limits inventory to 100 tokens, and sizes bids to available cash including the modeled fee. A sell requires owned tokens. Quotes that remain at the same price retain their estimated queue position across book updates. The default tick is 0.01 when the input lacks a tick size; a supplied book tick or tick change takes effect in replay. A market's actual minimum order size, available collateral rules, and exchange queue are not established by this simulator.
